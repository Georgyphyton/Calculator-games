### Hexlet tests and linter status:
[![Actions Status](https://github.com/Georgyphyton/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Georgyphyton/python-project-49/actions)
<a href="https://codeclimate.com/github/Georgyphyton/ru-my-first-pullrequest/maintainability"><img src="https://api.codeclimate.com/v1/badges/51aaf47658f0a896e471/maintainability" /></a>
